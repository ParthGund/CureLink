import api from './api';



/**
 * Fetch available time slots for a doctor on a given date.
 * @param {string} doctorId - Doctor MongoDB _id.
 * @param {string} date - Date string in YYYY-MM-DD format.
 * @returns {Promise<string[]>} Array of available time slot strings.
 */
export async function getAvailableSlots(doctorId, date) {
  const data = await api(`/doctors/${doctorId}/slots?date=${date}`);
  return data.slots;
}

/**
 * Book a new appointment.
 * @param {object} payload - { patient, doctorId, date, timeSlot, reason }
 * @returns {Promise<object>} The created appointment (populated).
 */
export async function bookAppointment(payload) {
  return api('/appointments', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

/**
 * Fetch appointments for the currently logged-in patient.
 * Uses the /api/appointments/me endpoint.
 * @returns {Promise<{ success: boolean, appointments: object[] }>}
 */
export async function getMyAppointments() {
  return api('/appointments/me');
}

/**
 * Cancel an existing appointment.
 * @param {string} id - Appointment MongoDB _id.
 * @returns {Promise<object>} The updated appointment.
 */
export async function cancelAppointment(id) {
  return api(`/appointments/${id}/cancel`, { method: 'PUT' });
}

/** Reschedule an existing appointment while retaining its record/history. */
export async function rescheduleAppointment(id, payload) {
  return api(`/appointments/${id}/reschedule`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

/**
 * Fetch appointments for the currently logged-in doctor.
 * Uses the /api/appointments/doctor/me endpoint.
 * @returns {Promise<{ success: boolean, appointments: object[] }>}
 */
export async function getDoctorAppointments() {
  return api('/appointments/doctor/me');
}

/**
 * Fetch a single appointment by ID.
 * @param {string} id - Appointment MongoDB _id.
 * @returns {Promise<{ success: boolean, appointment: object }>}
 */
export async function getAppointmentById(id) {
  return api(`/appointments/${id}`);
}
