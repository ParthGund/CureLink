const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema(
  {
    patient: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    doctor: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    date: { type: Date, required: true },
    timeSlot: { type: String, required: true },
    status: {
      type: String,
      enum: ["upcoming", "scheduled", "confirmed", "completed", "cancelled", "missed"],
      default: "scheduled",
    },
    reason: { type: String, trim: true },
    notes: { type: String, trim: true },
    rescheduleHistory: {
      type: [{
        previousDate: { type: Date, required: true },
        previousTimeSlot: { type: String, required: true },
        newDate: { type: Date, required: true },
        newTimeSlot: { type: String, required: true },
        changedAt: { type: Date, default: Date.now },
      }],
      default: [],
    },
  },
  { timestamps: true }
);

appointmentSchema.index(
  { doctor: 1, date: 1, timeSlot: 1 },
  { unique: true, partialFilterExpression: { status: { $in: ["upcoming", "scheduled", "confirmed"] } } }
);

module.exports = mongoose.model("Appointment", appointmentSchema);
