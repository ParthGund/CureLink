const mongoose = require('mongoose');
const Appointment = require('../models/Appointment');
const Patient = require('../models/Patient');
const Doctor = require('../models/Doctor');
const Consultation = require('../models/Consultation');
const { httpError } = require('../utils/httpError');
const scheduleService = require('./scheduleService');
const { toIsoDate, parseIsoDate } = require('../utils/timeUtils');

/**
 * Get the Patient document linked to an authenticated user.
 *
 * @param {string} userId - User._id from req.user.
 * @returns {Promise<object|null>} Patient document or null.
 */
async function getPatientForUser(userId) {
  return Patient.findOne({ userId });
}

/**
 * Get or create a Patient linked to the authenticated user.
 *
 * Supplementary fields (phone, dateOfBirth, gender) may be provided
 * from the request body. Identity (userId, fullName, email) always
 * comes from the authenticated user — never from the client.
 *
 * @param {object} user - req.user (User document).
 * @param {object} supplementary - Additional patient data from request body.
 * @returns {Promise<object>} Patient document.
 */
async function getOrCreatePatient(user, supplementary = {}) {
  let patient = await getPatientForUser(user._id);

  if (patient) {
    // Update supplementary fields if provided
    let changed = false;

    if (supplementary.phone && supplementary.phone !== patient.phone) {
      patient.phone = supplementary.phone;
      changed = true;
    }
    if (supplementary.dateOfBirth !== undefined) {
      patient.dateOfBirth = supplementary.dateOfBirth;
      changed = true;
    }
    if (supplementary.gender !== undefined) {
      patient.gender = supplementary.gender;
      changed = true;
    }

    if (changed) await patient.save();
    return patient;
  }

  // Phone is required by the Patient schema
  if (!supplementary.phone) {
    throw httpError(400, 'Phone number is required for your first appointment booking.');
  }

  patient = await Patient.create({
    fullName: user.name,
    email: user.email,
    phone: supplementary.phone,
    dateOfBirth: supplementary.dateOfBirth || undefined,
    gender: supplementary.gender || undefined,
    userId: user._id,
  });

  return patient;
}

/**
 * Book an appointment for the authenticated user.
 *
 * The patient identity is derived from req.user — the client cannot
 * specify which patient the appointment belongs to.
 *
 * @param {object} user - req.user (authenticated User document).
 * @param {object} input - { doctorId, date, timeSlot, reason, patientData }.
 * @returns {Promise<object>} Populated appointment document.
 */
async function bookAppointment(user, { doctorId, date, timeSlot, reason, patientData }) {
  // Validate doctor
  if (!mongoose.Types.ObjectId.isValid(doctorId)) {
    throw httpError(400, 'Invalid doctor ID.');
  }

  const doctor = await Doctor.findById(doctorId);
  if (!doctor) {
    throw httpError(404, 'Doctor not found.');
  }

  // Get or create patient from authenticated user
  const patient = await getOrCreatePatient(user, patientData || {});

  // Validate date
  const appointmentDate = new Date(date);
  if (isNaN(appointmentDate.getTime())) {
    throw httpError(400, 'Invalid date format.');
  }

  // Validate timeSlot
  if (!timeSlot || typeof timeSlot !== 'string' || timeSlot.trim().length === 0) {
    throw httpError(400, 'Time slot is required.');
  }

  const dayStart = new Date(appointmentDate);
  dayStart.setUTCHours(0, 0, 0, 0);
  const dayEnd = new Date(appointmentDate);
  dayEnd.setUTCHours(23, 59, 59, 999);

  const isoDate = toIsoDate(appointmentDate);
  const availableLabels = await scheduleService.getAvailableLabelsForDate(doctorId, isoDate);

  if (!availableLabels.includes(timeSlot)) {
    throw httpError(400, 'The requested time slot is invalid, unavailable, or does not exist for this date.');
  }

  // Explicit conflict check — catches race conditions before the unique index.
  // A slot is considered taken if an active appointment already exists for this
  // doctor / date / timeSlot combination.
  const conflict = await Appointment.findOne({
    doctor: doctorId,
    date: dayStart,
    timeSlot,
    status: { $in: ['scheduled', 'confirmed', 'upcoming'] },
  });

  if (conflict) {
    throw httpError(409, 'This slot has already been booked by another patient. Please choose a different time.');
  }

  // Create appointment with status 'scheduled' (enters lifecycle at the first active state)
  const appointment = await Appointment.create({
    patient: patient._id,
    doctor: doctorId,
    date: dayStart,
    timeSlot,
    reason: reason || '',
    status: 'scheduled',
  });

  return appointment.populate(['patient', 'doctor']);
}

/**
 * Get appointments for the authenticated user's patient profile.
 *
 * @param {string} userId - User._id from req.user.
 * @returns {Promise<object[]>} Array of appointment documents.
 */
async function getMyAppointments(userId) {
  const patient = await getPatientForUser(userId);

  if (!patient) {
    return [];
  }

  return Appointment.find({ patient: patient._id })
    .populate('doctor', 'name specialization email')
    .sort({ date: -1, timeSlot: 1 });
}

/**
 * Get appointment by ID with ownership verification.
 *
 * Only the owning patient, assigned doctor, or an admin may view.
 *
 * @param {string} appointmentId - Appointment._id.
 * @param {object} user - req.user (authenticated User document).
 * @returns {Promise<object>} Populated appointment document.
 */
async function getAppointmentById(appointmentId, user) {
  if (!mongoose.Types.ObjectId.isValid(appointmentId)) {
    throw httpError(404, 'Appointment not found.');
  }

  const appointment = await Appointment.findById(appointmentId)
    .populate(['patient', 'doctor']);

  if (!appointment) {
    throw httpError(404, 'Appointment not found.');
  }

  await verifyAppointmentAccess(appointment, user);

  return appointment;
}

/**
 * Cancel an appointment with ownership verification.
 *
 * Only the owning patient, assigned doctor, or an admin may cancel.
 *
 * @param {string} appointmentId - Appointment._id.
 * @param {object} user - req.user (authenticated User document).
 * @returns {Promise<object>} Updated appointment document.
 */
async function cancelAppointment(appointmentId, user) {
  if (!mongoose.Types.ObjectId.isValid(appointmentId)) {
    throw httpError(404, 'Appointment not found.');
  }

  const appointment = await Appointment.findById(appointmentId);

  if (!appointment) {
    throw httpError(404, 'Appointment not found.');
  }

  await verifyAppointmentAccess(appointment, user);

  if (appointment.status === 'cancelled') {
    throw httpError(400, 'Appointment is already cancelled.');
  }

  if (appointment.status === 'completed') {
    throw httpError(400, `Cannot cancel an appointment that is ${appointment.status}.`);
  }

  if (appointment.status === 'missed') {
    throw httpError(400, 'Cannot cancel an appointment that has already been marked as missed.');
  }

  const activeConsultation = await Consultation.findOne({
    appointment: appointmentId,
    status: { $in: ['in_progress', 'completed'] },
  });

  if (activeConsultation) {
    throw httpError(400, 'Cannot cancel an appointment that has an active or completed consultation.');
  }

  appointment.status = 'cancelled';
  await appointment.save();

  return appointment;
}

/**
 * Move an existing patient appointment to another available slot.
 * The appointment document is retained and each move is appended atomically.
 */
async function rescheduleAppointment(appointmentId, user, { date, timeSlot }) {
  if (!mongoose.Types.ObjectId.isValid(appointmentId)) {
    throw httpError(404, 'Appointment not found.');
  }
  const patient = await getPatientForUser(user._id);
  if (!patient) throw httpError(404, 'Patient profile not found.');

  const appointment = await Appointment.findOne({ _id: appointmentId, patient: patient._id });
  if (!appointment) throw httpError(404, 'Appointment not found.');
  if (!['scheduled', 'upcoming', 'confirmed'].includes(appointment.status)) {
    throw httpError(400, `Cannot reschedule an appointment that is ${appointment.status}.`);
  }

  if (await Consultation.exists({ appointment: appointment._id })) {
    throw httpError(409, 'An appointment with a consultation cannot be rescheduled.');
  }

  const newDate = parseIsoDate(date);
  if (!newDate) throw httpError(400, 'Choose a valid appointment date.');
  if (newDate < new Date(new Date().setUTCHours(0, 0, 0, 0))) {
    throw httpError(400, 'Cannot reschedule an appointment to a past date.');
  }
  if (appointment.date.getTime() === newDate.getTime() && appointment.timeSlot === timeSlot) {
    throw httpError(409, 'Choose a different date or time to reschedule.');
  }

  const isoDate = toIsoDate(newDate);
  const available = await scheduleService.getAvailableLabelsForDate(appointment.doctor, isoDate);
  if (!available.includes(timeSlot)) {
    throw httpError(409, 'That time is no longer available. Choose another slot.');
  }

  const updated = await Appointment.findOneAndUpdate(
    {
      _id: appointment._id,
      patient: patient._id,
      status: { $in: ['scheduled', 'upcoming', 'confirmed'] },
      date: appointment.date,
      timeSlot: appointment.timeSlot,
    },
    {
      $set: { date: newDate, timeSlot },
      $push: {
        rescheduleHistory: {
          previousDate: appointment.date,
          previousTimeSlot: appointment.timeSlot,
          newDate,
          newTimeSlot: timeSlot,
          changedAt: new Date(),
        },
      },
    },
    { new: true, runValidators: true }
  );

  if (!updated) throw httpError(409, 'This appointment changed while you were rescheduling. Refresh and try again.');
  return updated.populate(['patient', 'doctor']);
}

/**
 * Verify that the authenticated user has access to an appointment.
 *
 * Allowed relationships:
 *   - Patient who owns the appointment
 *   - Doctor assigned to the appointment
 *   - Admin
 *
 * @param {object} appointment - Appointment document (may be populated or not).
 * @param {object} user - req.user (authenticated User document).
 * @throws {Error} 403 if the user does not have access.
 */
async function verifyAppointmentAccess(appointment, user) {
  // Admins can access any appointment
  if (user.role === 'admin') return;

  // Doctor assigned to the appointment
  if (user.role === 'doctor') {
    const doctor = await Doctor.findOne({ user: user._id });
    const appointmentDoctorId = appointment.doctor._id || appointment.doctor;

    if (doctor && doctor._id.equals(appointmentDoctorId)) {
      return;
    }

    throw httpError(403, 'You do not have access to this appointment.');
  }

  // Patient who owns the appointment
  if (user.role === 'patient') {
    const patient = await getPatientForUser(user._id);
    const appointmentPatientId = appointment.patient._id || appointment.patient;

    if (patient && patient._id.equals(appointmentPatientId)) {
      return;
    }

    throw httpError(403, 'You do not have access to this appointment.');
  }

  throw httpError(403, 'You do not have access to this appointment.');
}

/**
 * Get the Doctor document linked to an authenticated user.
 *
 * @param {string} userId - User._id from req.user.
 * @returns {Promise<object|null>} Doctor document or null.
 */
async function getDoctorForUser(userId) {
  return Doctor.findOne({ user: userId });
}

/**
 * Get appointments for the authenticated doctor.
 *
 * The doctor identity is derived from req.user — the client cannot
 * specify which doctor's appointments to fetch.
 *
 * @param {string} userId - User._id from req.user.
 * @returns {Promise<object[]>} Array of populated appointment documents.
 */
async function getDoctorAppointments(userId) {
  const doctor = await getDoctorForUser(userId);

  if (!doctor) {
    throw httpError(
      404,
      'Your doctor profile has not been set up yet. Please contact an administrator.'
    );
  }

  return Appointment.find({ doctor: doctor._id })
    .populate('patient', 'fullName email phone')
    .populate('doctor', 'name specialization')
    .sort({ date: -1, timeSlot: 1 });
}

module.exports = {
  getPatientForUser,
  getOrCreatePatient,
  bookAppointment,
  getMyAppointments,
  getDoctorAppointments,
  getAppointmentById,
  cancelAppointment,
  rescheduleAppointment,
  verifyAppointmentAccess,
};
